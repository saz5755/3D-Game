using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayerController : MonoBehaviour
{
    [SerializeField] private Transform player;
    [SerializeField] private Transform cam;
    [SerializeField] private float speed = 5f;

    private CharacterController controller;
    private Vector3 moveDir = Vector3.zero;

    private float gravityY = .0f;
    private float horizontal = 0;
    private float vertical = 0;

    [SerializeField] private float angleX = .0f;
    [SerializeField] private float angleY = .0f;

    private bool isslow = false;
    private bool isgravityZone = false;
    private bool isDoubleJump = false;

    //private int jumpCount;
    private Text myScore;
    private int score = 0;


    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Locked;
        controller = player.GetComponent<CharacterController>();
    }

    private void Start()
    {
        myScore = GameObject.Find("Score").GetComponent<Text>();
    }

    void Update()
    {
        PlayerMove();
        PlayerRotate();
        PlayerShoot();
        SetCountText();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Sea")
        {
            Debug.Log("Sea�� ����");
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.name == "Sea")
        {
            isslow = true;
            player.GetComponent<PlayerController>().speed = 1f;
        }
        if (other.gameObject.name == "gravityZone")
        {
            isgravityZone = true;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        isslow = false;
        isgravityZone = false;
    }

    private void PlayerMove()
    {

        if (controller.isGrounded)
        {
            horizontal = Input.GetAxis("Horizontal");
            vertical = Input.GetAxis("Vertical");
            isDoubleJump = true;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                if (isgravityZone)
                {
                    gravityY = 10f;
                }
                else
                {
                    gravityY = 6f;
                }
            }

        }
        else
        {
            gravityY += (Physics.gravity.y * Time.deltaTime);

            if (isDoubleJump)
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    gravityY = 6f;
                    isDoubleJump = false;
                }
            }
            
        }

        moveDir = new Vector3(horizontal, 0, vertical);

        if (moveDir.magnitude > 1)
        {
            moveDir.Normalize();
        }

        moveDir *= speed;
        moveDir.y = gravityY;

        if (isslow)
        {
            if (Input.GetKey(KeyCode.LeftShift))            //ex) ������ ���ġ�� ����
            {
                speed = 3f;
            }
        }
        else
        {
            if (Input.GetKey(KeyCode.LeftControl))
            {
                speed = 10f;
            }
            else
            {
                speed = 5f;
            }
        }
        controller.Move(Quaternion.Euler(new Vector3(0, angleY, 0)) * moveDir * Time.deltaTime);
    }

    private void PlayerRotate()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        angleY += mouseX;
        angleX -= mouseY;

        cam.position = player.position;
        cam.rotation = Quaternion.Euler(new Vector3(angleX, angleY, 0));
    }

    private void PlayerShoot()
    {
        if (Input.GetMouseButton(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                if (hit.collider.gameObject.name == "Target")
                {
                    score += 1;
                    Destroy(hit.collider.gameObject);
                }
            }
        }
    }
    private void SetCountText()
    {
        myScore.text = "[Score] : " + score.ToString();
    }

}